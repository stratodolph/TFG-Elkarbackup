Elkarbackup Windows Client
Version 1.1

PREREQ
#######
1. Windows 10 64 bits
2. OS Bulid 14393.0 or later (Settings > System > About)
Choose one way:
3a. Enable Developer Mode (Settings -> Update and Security -> For developers)
4a. Enable Linux Subsystem

3b. Execute PreInstall.bat as administrator

5. Reboot

INSTALL
########
1. Execute normal (double click) Config_file.bat
2. With Admin privileges (as administrator) execute Install.bat

UNINSTALL
##########
Uninstall All:
- With Admin privileges (as administrator) execute Uninstall_All.bat
Uninstall Elkarbackup Client:
- With Admin privileges (as administrator) execute Uninstall_EBCli.bat
Uninstall Linux Subsystem:
- With Admin privileges (as administrator) execute Uninstall_Linux_Subsystem.bat